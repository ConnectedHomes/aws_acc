# -*- coding: utf-8 -*-
from distutils.core import setup

packages = \
['aws_acc']

package_data = \
{'': ['*']}

setup_kwargs = {
    'name': 'aws-acc',
    'version': '0.1.0',
    'description': '',
    'long_description': '# debsaws\n',
    'author': 'debswade',
    'author_email': 'deborah.balm@hivehome.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': 'https://github.com/debswade/aws_acc',
    'packages': packages,
    'package_data': package_data,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
